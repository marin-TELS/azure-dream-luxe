# Variables d'environnement — Villa Azur

À configurer dans Vercel → Settings → Environment Variables

## Supabase (projet existant)
```
SUPABASE_URL=https://dclonxvipkzcujrrtppu.supabase.co
SUPABASE_SERVICE_KEY=<ta clé service — Supabase Dashboard → Settings → API → service_role>
```

## Resend
```
RESEND_API_KEY=<ta clé API Resend>
```

## Emails
```
PROPRIETAIRE_EMAIL=contact@villa-azur.fr
FROM_EMAIL=reservations@villa-azur.fr
```

---

## Tables Supabase créées ✓
- `reservations` — toutes les demandes de réservation
- `periodes_bloquees` — périodes non disponibles (congés, travaux…)

## Endpoints API Vercel
- `POST /api/reserve` — soumet une demande de réservation
- `GET /api/disponibilites` — retourne les dates bloquées pour le calendrier
