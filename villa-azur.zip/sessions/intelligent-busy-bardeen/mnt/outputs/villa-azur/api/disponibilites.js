import { createClient } from "@supabase/supabase-js";

const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_KEY
);

export default async function handler(req, res) {
  if (req.method !== "GET") {
    return res.status(405).json({ error: "Méthode non autorisée" });
  }

  // Récupérer les périodes bloquées
  const { data: periodes, error } = await supabase
    .from("periodes_bloquees")
    .select("date_debut, date_fin")
    .gte("date_fin", new Date().toISOString().split("T")[0]);

  if (error) {
    return res.status(500).json({ error: "Erreur base de données" });
  }

  // Récupérer aussi les réservations confirmées
  const { data: reservations } = await supabase
    .from("reservations")
    .select("date_arrivee, date_depart")
    .eq("statut", "confirmee")
    .gte("date_depart", new Date().toISOString().split("T")[0]);

  const toutesLesBloquees = [
    ...(periodes || []),
    ...(reservations || []).map((r) => ({
      date_debut: r.date_arrivee,
      date_fin: r.date_depart,
    })),
  ];

  res.setHeader("Cache-Control", "s-maxage=300"); // Cache 5 min
  return res.status(200).json({ periodes: toutesLesBloquees });
}
