import { createClient } from "@supabase/supabase-js";
import { Resend } from "resend";

const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_KEY
);
const resend = new Resend(process.env.RESEND_API_KEY);

const PROPRIETAIRE_EMAIL = process.env.PROPRIETAIRE_EMAIL;
const FROM_EMAIL = process.env.FROM_EMAIL || "reservations@villa-azur.fr";

export default async function handler(req, res) {
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Méthode non autorisée" });
  }

  const { date_arrivee, date_depart, nom, email, telephone, nb_personnes, message } = req.body;

  // Validation basique côté serveur
  if (!date_arrivee || !date_depart || !nom || !email || !nb_personnes) {
    return res.status(400).json({ error: "Champs obligatoires manquants" });
  }

  // Vérifier les conflits avec les réservations existantes confirmées
  const { data: conflits } = await supabase
    .from("reservations")
    .select("id")
    .eq("statut", "confirmee")
    .lt("date_arrivee", date_depart)
    .gt("date_depart", date_arrivee);

  if (conflits && conflits.length > 0) {
    return res.status(409).json({ error: "Ces dates ne sont plus disponibles" });
  }

  // Enregistrer dans Supabase
  const { error: dbError } = await supabase.from("reservations").insert([{
    date_arrivee,
    date_depart,
    nom,
    email,
    telephone: telephone || null,
    nb_personnes,
    message: message || null,
    statut: "en_attente",
    bien: "villa-azur",
  }]);

  if (dbError) {
    console.error("Supabase error:", dbError);
    return res.status(500).json({ error: "Erreur base de données" });
  }

  // Formater les dates pour les emails
  const fmt = (d) => new Date(d).toLocaleDateString("fr-FR", {
    day: "numeric", month: "long", year: "numeric"
  });

  // Email au propriétaire
  await resend.emails.send({
    from: FROM_EMAIL,
    to: PROPRIETAIRE_EMAIL,
    subject: `🏠 Nouvelle demande — ${nom} · ${fmt(date_arrivee)} → ${fmt(date_depart)}`,
    html: `
      <div style="font-family: sans-serif; max-width: 500px; margin: 0 auto;">
        <h2 style="color: #b8965a;">Nouvelle demande de réservation</h2>
        <table style="width:100%; border-collapse: collapse;">
          <tr><td style="padding: 8px 0; color: #666;">Nom</td><td><strong>${nom}</strong></td></tr>
          <tr><td style="padding: 8px 0; color: #666;">Email</td><td><a href="mailto:${email}">${email}</a></td></tr>
          <tr><td style="padding: 8px 0; color: #666;">Téléphone</td><td>${telephone || "Non renseigné"}</td></tr>
          <tr><td style="padding: 8px 0; color: #666;">Arrivée</td><td><strong>${fmt(date_arrivee)}</strong></td></tr>
          <tr><td style="padding: 8px 0; color: #666;">Départ</td><td><strong>${fmt(date_depart)}</strong></td></tr>
          <tr><td style="padding: 8px 0; color: #666;">Personnes</td><td>${nb_personnes}</td></tr>
          <tr><td style="padding: 8px 0; color: #666; vertical-align:top;">Message</td><td>${message || "—"}</td></tr>
        </table>
        <p style="margin-top: 24px; color: #888; font-size: 12px;">Demande reçue via villa-azur.fr</p>
      </div>
    `,
  });

  // Email de confirmation au visiteur
  await resend.emails.send({
    from: FROM_EMAIL,
    to: email,
    subject: "Villa Azur — Votre demande a bien été reçue",
    html: `
      <div style="font-family: sans-serif; max-width: 500px; margin: 0 auto;">
        <h2 style="font-family: Georgia, serif; color: #0f0f0f;">Bonjour ${nom},</h2>
        <p>Nous avons bien reçu votre demande pour la période du <strong>${fmt(date_arrivee)}</strong> au <strong>${fmt(date_depart)}</strong> (${nb_personnes} personnes).</p>
        <p style="margin-top: 16px;">Nous étudions votre demande et vous répondons <strong>sous 24h</strong> avec les disponibilités et les modalités.</p>
        <p style="margin-top: 16px;">Pour toute question urgente, vous pouvez nous contacter directement à <a href="mailto:${PROPRIETAIRE_EMAIL}" style="color: #b8965a;">${PROPRIETAIRE_EMAIL}</a>.</p>
        <hr style="margin: 32px 0; border: none; border-top: 1px solid #e8e0d4;" />
        <p style="color: #888; font-size: 13px;">Villa Azur · Biarritz, Pays Basque</p>
      </div>
    `,
  });

  return res.status(200).json({ success: true });
}
