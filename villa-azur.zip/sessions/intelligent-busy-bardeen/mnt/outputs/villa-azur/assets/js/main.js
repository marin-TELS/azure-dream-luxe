// ── Calendrier flatpickr ──
const arrivee = flatpickr("#date-arrivee", {
  locale: "fr",
  dateFormat: "Y-m-d",
  altInput: true,
  altFormat: "j F Y",
  minDate: "today",
  disableMobile: true,
  onChange: function (selectedDates) {
    const minDepart = new Date(selectedDates[0]);
    minDepart.setDate(minDepart.getDate() + 2);
    depart.set("minDate", minDepart);
    if (depart.selectedDates[0] && depart.selectedDates[0] <= selectedDates[0]) {
      depart.clear();
    }
  },
});

const depart = flatpickr("#date-depart", {
  locale: "fr",
  dateFormat: "Y-m-d",
  altInput: true,
  altFormat: "j F Y",
  minDate: "today",
  disableMobile: true,
});

// Charger les périodes bloquées depuis Supabase
async function chargerPeriodesBloquees() {
  try {
    const res = await fetch("/api/disponibilites");
    if (!res.ok) return;
    const { periodes } = await res.json();
    if (!periodes || periodes.length === 0) return;

    const disabled = periodes.map((p) => ({
      from: p.date_debut,
      to: p.date_fin,
    }));
    arrivee.set("disable", disabled);
    depart.set("disable", disabled);
  } catch (e) {
    console.warn("Impossible de charger les disponibilités", e);
  }
}
chargerPeriodesBloquees();

// ── Soumission du formulaire ──
const form = document.getElementById("form-reservation");
const statusEl = document.getElementById("form-status");
const btnSubmit = document.getElementById("btn-submit");

form.addEventListener("submit", async (e) => {
  e.preventDefault();

  const required = ["date-arrivee", "date-depart", "nom", "email", "nb-personnes"];
  let valid = true;
  required.forEach((id) => {
    const el = document.getElementById(id);
    if (!el.value.trim()) {
      el.style.borderColor = "#c0392b";
      valid = false;
    } else {
      el.style.borderColor = "";
    }
  });
  if (!valid) {
    showStatus("Merci de remplir tous les champs obligatoires.", "error");
    return;
  }

  btnSubmit.disabled = true;
  btnSubmit.textContent = "Envoi en cours…";

  const data = {
    date_arrivee: document.getElementById("date-arrivee").value,
    date_depart: document.getElementById("date-depart").value,
    nom: document.getElementById("nom").value.trim(),
    email: document.getElementById("email").value.trim(),
    telephone: document.getElementById("telephone").value.trim(),
    nb_personnes: parseInt(document.getElementById("nb-personnes").value),
    message: document.getElementById("message").value.trim(),
  };

  try {
    const res = await fetch("/api/reserve", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data),
    });

    if (res.ok) {
      showStatus("✓ Demande envoyée ! Nous vous répondons sous 24h.", "success");
      form.reset();
      arrivee.clear();
      depart.clear();
    } else {
      const err = await res.json();
      throw new Error(err.error || "Erreur serveur");
    }
  } catch (err) {
    console.error(err);
    showStatus(
      "Une erreur est survenue. Écrivez-nous directement à contact@villa-azur.fr",
      "error"
    );
  } finally {
    btnSubmit.disabled = false;
    btnSubmit.textContent = "Envoyer ma demande";
  }
});

function showStatus(msg, type) {
  statusEl.textContent = msg;
  statusEl.className = `form-status ${type}`;
  statusEl.scrollIntoView({ behavior: "smooth", block: "nearest" });
}
